package DefiningClasses.Exercises.SpeedRacing;

import java.text.DecimalFormat;

public class Car {
    private String model;
    private double fuelAmount;
    private double fuelCostPerKm;
    private double distanceTraveled;

    public Car(String model, double fuelAmount, double fuelCostForKm) {
        this.model = model;
        this.fuelAmount = fuelAmount;
        this.fuelCostPerKm = fuelCostForKm;
        distanceTraveled = 0.0;
    }

    public boolean hasEnoughFuel(double distanceToTravel) {
        double possibleDistance = this.fuelAmount / this.fuelCostPerKm;
        return distanceToTravel <= possibleDistance;
    }

    public void setDistanceTraveled(double distanceToTravel) {
        this.distanceTraveled = this.distanceTraveled + distanceToTravel;
    }

    public double getDistanceTraveled() {
        return distanceTraveled;
    }

    public void newFuelAmount(double distanceToTravel) {
        this.fuelAmount = this.fuelAmount - distanceToTravel*this.fuelCostPerKm;
    }

    @Override
    public String toString() {
        DecimalFormat decimalFormat = new DecimalFormat("##.##");
        return String.format("%s %.2f %s",this.model,this.fuelAmount,decimalFormat.format(this.distanceTraveled));
    }
}
